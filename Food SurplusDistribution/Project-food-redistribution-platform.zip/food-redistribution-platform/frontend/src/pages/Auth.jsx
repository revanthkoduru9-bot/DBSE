import { useState } from 'react'; import { Link, useNavigate } from 'react-router-dom'; import { useAuth } from '../context/Auth'; import { err } from '../services/api'; import toast from '../utils/toast';
export default function Auth({ mode }) {
  const { login, register } = useAuth(), nav = useNavigate(), reg = mode === 'register';
  const [f, setF] = useState({}), [busy, setBusy] = useState(false);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const submit = async e => { e.preventDefault(); setBusy(true); try { const b = Object.fromEntries(Object.entries(f).filter(([, v]) => v !== '')); await (reg ? register(b) : login(b)); nav('/dashboard'); } catch (x) { toast(err(x), 1); } setBusy(false); };
  return <div className="wrap narrow"><form className="card pad form" onSubmit={submit}><h2>{reg ? 'Create your account' : 'Welcome back'}</h2>
    {reg && <p className="mut">One account, one login — you can donate food, request food as an NGO, and volunteer for pickups, all from the same place.</p>}
    {reg && <><label>Full name<input required onChange={set('name')} /></label><label>Phone<input onChange={set('phone')} /></label></>}
    <label>Email<input type="email" required onChange={set('email')} /></label><label>Password<input type="password" required minLength="6" onChange={set('password')} /></label>
    {reg && <><label>Address<input onChange={set('address')} /></label><div className="row"><label>City<input onChange={set('city')} /></label><label>State<input onChange={set('state')} /></label></div></>}
    <button className="btn" disabled={busy}>{busy ? 'Please wait…' : reg ? 'Register' : 'Login'}</button>
    <p className="mut">{reg ? <>Have an account? <Link to="/login">Login</Link></> : <>New here? <Link to="/register">Register</Link> · <a href="#" onClick={e => { e.preventDefault(); toast('Please contact the platform admin to reset your password'); }}>Forgot password?</a></>}</p></form></div>;
}
