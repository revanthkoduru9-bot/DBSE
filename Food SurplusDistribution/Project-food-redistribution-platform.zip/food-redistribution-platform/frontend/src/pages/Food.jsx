import { useEffect, useState } from 'react'; import { useNavigate } from 'react-router-dom'; import api, { err } from '../services/api';
import FoodCard, { CATS } from '../components/FoodCard'; import { useAuth } from '../context/Auth'; import toast from '../utils/toast';
export default function Food() {
  const { user } = useAuth(), nav = useNavigate();
  const [fl, setFl] = useState({ q: '', location: '', category: '', food_type: '', min_quantity: '', availability: 'available', radius: '' }), [pos, setPos] = useState({});
  const [rows, setRows] = useState(null), [req, setReq] = useState(null), [fm, setFm] = useState({}), [sending, setSending] = useState(false);
  useEffect(() => {
    const p = { ...fl, ...pos }; Object.keys(p).forEach(k => p[k] === '' && delete p[k]);
    const t = setTimeout(() => api.get('/food', { params: p }).then(r => setRows(r.data)).catch(e => { toast(err(e), 1); setRows([]); }), 300);
    return () => clearTimeout(t);
  }, [fl, pos]);
  const set = k => e => setFl({ ...fl, [k]: e.target.value });
  const locate = () => navigator.geolocation?.getCurrentPosition(p => { setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); setFl(x => ({ ...x, radius: x.radius || '10' })); }, () => toast('Location permission denied', 1));
  const open = f => { if (!user) return nav('/login'); setFm({ requested_quantity: f.quantity, requested_servings: f.servings }); setReq(f); };
  const send = async e => { e.preventDefault(); if (sending) return; setSending(true); try { await api.post('/requests', { ...fm, food_listing_id: req.id }); toast('Request sent to the donor'); setReq(null); nav('/dashboard/ngo'); } catch (x) { toast(err(x), 1); setReq(null); setFl(v => ({ ...v })); } setSending(false); };
  const fs = k => e => setFm({ ...fm, [k]: e.target.value });
  return <div className="wrap"><h2>Available Food</h2>
    <div className="filters">
      <input placeholder="Search food…" value={fl.q} onChange={set('q')} /><input placeholder="Location (e.g. Miyapur)" value={fl.location} onChange={set('location')} />
      <select value={fl.category} onChange={set('category')}><option value="">All categories</option>{CATS.map(c => <option key={c}>{c}</option>)}</select>
      <select value={fl.food_type} onChange={set('food_type')}><option value="">Veg & Non-veg</option><option value="veg">Veg</option><option value="non-veg">Non-veg</option></select>
      <input type="number" min="0" placeholder="Min quantity" value={fl.min_quantity} onChange={set('min_quantity')} />
      <select value={fl.availability} onChange={set('availability')}><option value="available">Available now</option><option value="all">Include requested</option></select>
      <select value={fl.radius} onChange={set('radius')}><option value="">Any distance</option>{[5, 10, 25].map(r => <option key={r} value={r}>Within {r} km</option>)}</select>
      <button className="btn alt" onClick={locate}>📍 Near me</button></div>
    {rows === null ? <p>Loading…</p> : rows.length === 0 ? <p className="empty">No food matches your filters right now.</p> : <div className="grid g3">{rows.map(f => <FoodCard key={f.id} f={f} onRequest={open} />)}</div>}
    {req && <div className="modal" onClick={() => setReq(null)}><form className="card pad form" onClick={e => e.stopPropagation()} onSubmit={send}>
      <h3>Request {req.food_name}</h3>
      <label>Quantity ({req.unit}, max {req.quantity})<input type="number" required min="1" max={req.quantity} value={fm.requested_quantity} onChange={fs('requested_quantity')} /></label>
      <label>People to serve<input type="number" required min="1" value={fm.requested_servings} onChange={fs('requested_servings')} /></label>
      <label>Preferred pickup time<input type="datetime-local" onChange={e => setFm({ ...fm, preferred_pickup_time: e.target.value ? new Date(e.target.value).toISOString() : '' })} /></label>
      <label>Message<textarea onChange={fs('message')} /></label><button className="btn" disabled={sending}>{sending ? 'Sending…' : 'Send Request'}</button></form></div>}
  </div>;
}
