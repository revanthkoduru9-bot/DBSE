import { useEffect, useState } from 'react'; import { Link } from 'react-router-dom'; import api, { err } from '../services/api'; import { useAuth } from '../context/Auth'; import toast from '../utils/toast';
const L = { donor: { total: 'Total Donations', active: 'Active Donations', peopleServed: 'People Served', pending: 'Pending Requests', completed: 'Completed Donations' }, ngo: { available: 'Available Food', sent: 'Requests Sent', approved: 'Approved Requests', received: 'Received Donations', peopleServed: 'People Served' }, volunteer: { available: 'Available Tasks', accepted: 'Accepted Tasks', completed: 'Completed Deliveries', peopleHelped: 'People Helped' }, admin: { users: 'Total Users', donors: 'Donors', ngos: 'NGOs', volunteers: 'Volunteers', available: 'Available Food', peopleServed: 'People Served', pendingRequests: 'Pending Requests', completed: 'Completed Donations' } };
// Backend statuses are lowercase (available, pending, approved, rejected, cancelled, accepted, picked_up,
// delivered, completed); this only maps them to the labels people see.
const LABEL = { available: 'Available', requested: 'Requested', removed: 'Removed', open: 'Open', pending: 'Pending', approved: 'Approved', rejected: 'Rejected', cancelled: 'Cancelled', accepted: 'Accepted', picked_up: 'Picked Up', delivered: 'Delivered', completed: 'Completed' };
const Badge = ({ s }) => <span className={'tag st-' + s}>{LABEL[s] || String(s).replace(/_/g, ' ')}</span>;
// Runs an API call, shows the REAL outcome (never pretends success), and reloads the data either way so the
// screen always matches the database - after a failure too (e.g. someone else already changed the status).
const act = async (fn, reload, ok = 'Updated') => { try { await fn(); toast(ok); reload(); return true; } catch (e) { toast(err(e), 1); reload(); return false; } };
// One action at a time per panel: buttons are disabled while a request is in flight (no duplicate clicks).
function useRun(reload) { const [busy, setBusy] = useState(null); const run = async (key, fn, ok) => { if (busy) return false; setBusy(key); try { return await act(fn, reload, ok); } finally { setBusy(null); } }; return [busy, run]; }
const Bars = ({ title, rows }) => { const m = Math.max(1, ...rows.map(r => r.n)); return <div className="card pad"><h3>{title}</h3>{rows.length ? rows.map(r => <div className="bar" key={r.k}><span>{r.k}</span><i style={{ width: (r.n / m * 100) + '%' }} /><b>{r.n}</b></div>) : <p className="empty">No data yet</p>}</div>; };
// On failure the result is an empty array flagged with .failed (the message) so the UI can say "could not
// load" instead of wrongly claiming there is nothing to show.
function useGet(url, tick) { const [d, setD] = useState(null); useEffect(() => { let live = true; api.get(url).then(r => live && setD(r.data)).catch(e => { if (!live) return; toast(err(e), 1); setD(Object.assign([], { failed: err(e) })); }); return () => { live = false; }; }, [url, tick]); return d; }
const Async = ({ d, empty, children }) => !d ? <p>Loading…</p> : d.failed ? <p className="empty">Could not load: {d.failed}</p> : !d.length ? <p className="empty">{empty}</p> : children(d);
const Stats = ({ d, kind }) => <div className="grid g5">{Object.entries(L[kind]).map(([k, l]) => <div className="card pad center" key={k}><div className="big">{d?.[k] ?? '–'}</div><div className="mut">{l}</div></div>)}</div>;

// Generic "edit my profile for this capability" form — used from the NGO (and optionally
// Donor/Volunteer) panels so a user never has to register a separate account for it.
function ProfileEditor({ type, fields, onDone }) {
  const [open, setOpen] = useState(false), [f, setF] = useState(null), [busy, setBusy] = useState(false);
  const load = () => api.get('/profile/' + type).then(r => setF(r.data || {})).catch(() => setF({}));
  const openForm = () => { load(); setOpen(true); };
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const save = async e => { e.preventDefault(); setBusy(true); try { await api.put('/profile/' + type, f); toast('Profile saved'); setOpen(false); onDone && onDone(); } catch (x) { toast(err(x), 1); } setBusy(false); };
  return <><button type="button" className="btn sm alt" onClick={openForm}>Edit {type === 'ngo' ? 'NGO' : type[0].toUpperCase() + type.slice(1)} Profile</button>
    {open && <div className="modal" onClick={() => setOpen(false)}><form className="card pad form" onClick={e => e.stopPropagation()} onSubmit={save}>
      <h3>{type === 'ngo' ? 'NGO' : type[0].toUpperCase() + type.slice(1)} profile</h3>
      {!f ? <p>Loading…</p> : fields.map(([k, l]) => <label key={k}>{l}<input value={f[k] || ''} onChange={set(k)} /></label>)}
      <button className="btn" disabled={busy || !f}>{busy ? 'Saving…' : 'Save'}</button></form></div>}</>;
}

function DonorPanel({ reload, tick }) {
  const reqs = useGet('/requests?view=donor', tick), mine = useGet('/food/mine', tick), [busy, run] = useRun(reload);
  const set = (id, status) => run(status + id, () => api.put(`/requests/${id}/status`, { status }), 'Request ' + status);
  return <><div className="actions"><Link className="btn" to="/add-food">+ Add Food Donation</Link> <ProfileEditor type="donor" fields={[['organization_name', 'Organization / business name'], ['address', 'Address'], ['city', 'City'], ['state', 'State']]} onDone={reload} /></div>
    <h3>Requests for my food</h3><Async d={reqs} empty="No requests yet.">{rows => rows.map(x => <div className="card pad row" key={x.id}><div><b>{x.FoodListing?.food_name}</b> — {x.Ngo?.organization_name}<br /><span className="mut">{x.requested_quantity} {x.FoodListing?.unit} · {x.requested_servings} people{x.message ? ' · ' + x.message : ''}</span></div><Badge s={x.status} />{x.status === 'pending' && <div><button className="btn" disabled={!!busy} onClick={() => set(x.id, 'approved')}>Approve</button> <button className="btn alt" disabled={!!busy} onClick={() => set(x.id, 'rejected')}>Reject</button></div>}</div>)}</Async>
    <h3>My donations & history</h3><Async d={mine} empty="You haven't listed any food yet.">{rows => rows.map(f => <div className="card pad row" key={f.id}><div><b>{f.food_name}</b><br /><span className="mut">{f.quantity} {f.unit} · {new Date(f.created_at).toLocaleDateString()}</span></div><Badge s={f.status} />{f.status === 'available' && <button className="btn alt" disabled={!!busy} onClick={() => run('rm' + f.id, () => api.delete('/food/' + f.id), 'Removed')}>Remove</button>}</div>)}</Async></>;
}
function NgoPanel({ reload, tick }) {
  const reqs = useGet('/requests?view=ngo', tick), [busy, run] = useRun(reload);
  // Confirm receipt: the request is completed on the server FIRST; the optional rating is a separate step so a
  // rating problem can never make a successful confirmation look like a failure.
  const done = async x => {
    if (!(await run('done' + x.id, () => api.put(`/requests/${x.id}/status`, { status: 'completed' }), 'Receipt confirmed'))) return;
    const r = prompt('Rate this donation (1-5)? Leave empty to skip.');
    if (r) try { await api.post('/feedback', { donationId: x.food_listing_id, rating: r }); toast('Thanks for the feedback'); } catch (e) { toast(err(e), 1); }
  };
  return <><div className="actions"><Link className="btn" to="/food">Find Food</Link> <ProfileEditor type="ngo" fields={[['organization_name', 'Organization name'], ['registration_number', 'Registration number'], ['address', 'Address'], ['city', 'City'], ['state', 'State'], ['service_area', 'Service area']]} onDone={reload} /></div><h3>My requests</h3>
    <Async d={reqs} empty="No requests yet — find food to get started.">{rows => rows.map(x => <div className="card pad row" key={x.id}><div><b>{x.FoodListing?.food_name}</b> from {x.FoodListing?.Donor?.organization_name}<br /><span className="mut">{x.requested_quantity} {x.FoodListing?.unit} · Pickup: {x.FoodListing?.pickup_address}</span></div><Badge s={x.status} />
      {['pending', 'approved'].includes(x.status) && <button className="btn alt" disabled={!!busy} onClick={() => run('c' + x.id, () => api.put(`/requests/${x.id}/status`, { status: 'cancelled' }), 'Cancelled')}>Cancel</button>}{x.status === 'delivered' && <button className="btn" disabled={!!busy} onClick={() => done(x)}>{busy === 'done' + x.id ? 'Confirming…' : 'Confirm receipt'}</button>}</div>)}</Async></>;
}
function VolunteerPanel({ reload, tick }) {
  const ts = useGet('/pickups', tick), [busy, run] = useRun(reload), go = (id, st) => run(st + id, () => api.put(`/pickups/${id}/status`, { status: st }), 'Status updated');
  const map = f => f?.latitude ? <a href={`https://www.openstreetmap.org/?mlat=${f.latitude}&mlon=${f.longitude}#map=16/${f.latitude}/${f.longitude}`} target="_blank" rel="noreferrer">Map</a> : null;
  return <><div className="actions"><ProfileEditor type="volunteer" fields={[['availability', 'Availability (e.g. weekends)'], ['address', 'Address'], ['city', 'City'], ['state', 'State']]} onDone={reload} /></div><h3>Pickup tasks</h3>
    <Async d={ts} empty="No tasks right now. Check back soon!">{rows => rows.map(t => { const x = t.FoodRequest, f = x.FoodListing, st = t.volunteer_id ? x.status : 'open';
      return <div className="card pad row" key={t.id}><div><b>{f?.food_name}</b> ({x.requested_quantity} {f?.unit})<br /><span className="mut">Pickup: {f?.pickup_address} {map(f)}<br />Drop: {x.Ngo?.organization_name}, {x.Ngo?.address}</span></div><Badge s={st} />
        {!t.volunteer_id && x.status === 'approved' && <button className="btn" disabled={!!busy} onClick={() => run('acc' + t.id, () => api.post(`/pickups/${t.id}/accept`), 'Task accepted')}>Accept</button>}{t.volunteer_id && x.status === 'accepted' && <button className="btn" disabled={!!busy} onClick={() => go(t.id, 'picked_up')}>Mark Picked Up</button>}{t.volunteer_id && x.status === 'picked_up' && <button className="btn" disabled={!!busy} onClick={() => go(t.id, 'delivered')}>Mark Delivered</button>}</div>; })}</Async></>;
}
function AdminPanel({ reload, tick }) {
  const us = useGet('/admin/users', tick), sx = useGet('/admin/statistics', tick), fs = useGet('/food?availability=all', tick);
  const up = (id, b) => act(() => api.put(`/admin/users/${id}/status`, b), reload);
  const caps = u => [['donor', u.Donor], ['ngo', u.Ngo], ['volunteer', u.Volunteer]].filter(([, p]) => p);
  return <>{sx?.byCapability && <div className="grid g3"><Bars title="Profiles by capability" rows={sx.byCapability} /><Bars title="Food categories" rows={sx.byCategory} /><Bars title="Donations per month" rows={sx.monthly} /></div>}
    <h3>Users</h3><p className="mut">Each account can carry any combination of Donor / NGO / Volunteer profiles.</p>
    <div className="scroll"><table><thead><tr><th>Name</th><th>Status</th><th>Capabilities</th><th></th></tr></thead><tbody>{(us || []).filter(u => u.role !== 'admin').map(u => <tr key={u.id}><td>{u.name}<br /><span className="mut">{u.email}</span></td><td>{u.status}</td>
      <td>{caps(u).length ? caps(u).map(([t, p]) => <div key={t}>{t}: {p.verification_status}{p.verification_status !== 'verified' && <button className="btn sm" onClick={() => up(u.id, { profileType: t, verification_status: 'verified' })}>Verify</button>}</div>) : <span className="mut">none yet</span>}</td>
      <td><button className="btn sm alt" onClick={() => up(u.id, { status: u.status === 'active' ? 'blocked' : 'active' })}>{u.status === 'active' ? 'Block' : 'Unblock'}</button></td></tr>)}</tbody></table></div>
    <h3>All listings</h3>{(fs || []).slice(0, 15).map(f => <div className="card pad row" key={f.id}><div><b>{f.food_name}</b> — {f.Donor?.organization_name}</div><Badge s={f.status} />{f.status === 'available' && <button className="btn sm alt" onClick={() => act(() => api.delete('/food/' + f.id), reload, 'Listing removed')}>Remove</button>}</div>)}</>;
}

function Notifications({ reload, tick }) {
  const nt = useGet('/notifications', tick);
  return <><h3>Notifications {nt?.some(n => !n.read) && <button className="btn sm alt" onClick={() => act(() => api.put('/notifications/read'), reload, 'Marked read')}>Mark all read</button>}</h3>
    {!nt?.length ? <p className="empty">You're all caught up.</p> : nt.map(n => <div key={n.id} className={'card pad note' + (n.read ? '' : ' unread')}><b>{n.title}</b> — {n.message}<div className="mut">{new Date(n.created_at).toLocaleString()}</div></div>)}</>;
}

// Common hub shown right after login: one account, three activities, switch freely.
export function Hub() {
  const { user } = useAuth(), [tick, setT] = useState(0);
  const cards = [['donor', '🍱', 'Donate Food', 'List surplus food for NGOs to request.'], ['ngo', '🏢', 'NGO / Request Food', 'Browse available food and request it.'], ['volunteer', '🤝', 'Volunteer', 'Accept pickup & delivery tasks.']];
  return <div className="wrap"><h2>Welcome, {user.name}!</h2><p className="mut">What would you like to do today? Switch between these anytime — it's all the same account.</p>
    <div className="grid g3">{cards.map(([k, ico, title, desc]) => <Link className="card pad center" to={'/dashboard/' + k} key={k} style={{ textDecoration: 'none', color: 'inherit' }}><div className="ico">{ico}</div><h3>{title}</h3><p className="mut">{desc}</p></Link>)}</div>
    <Notifications reload={() => setT(t => t + 1)} tick={tick} /></div>;
}
function CapabilityDashboard({ kind, title, Panel, url }) {
  const [tick, setT] = useState(0), reload = () => setT(t => t + 1), d = useGet(url, tick);
  return <div className="wrap"><p><Link to="/dashboard">← Back to dashboard</Link></p><h2>{title}</h2>
    <Stats d={d} kind={kind} /><Panel reload={reload} tick={tick} /></div>;
}
export const DonorDashboard = () => <CapabilityDashboard kind="donor" title="🍱 Donate Food" Panel={DonorPanel} url="/dashboard/donor" />;
export const NgoDashboard = () => <CapabilityDashboard kind="ngo" title="🏢 NGO / Request Food" Panel={NgoPanel} url="/dashboard/ngo" />;
export const VolunteerDashboard = () => <CapabilityDashboard kind="volunteer" title="🤝 Volunteer" Panel={VolunteerPanel} url="/dashboard/volunteer" />;
export default function Dashboard() {
  const { user } = useAuth(), [tick, setT] = useState(0), reload = () => setT(t => t + 1), d = useGet('/admin/dashboard', tick);
  return <div className="wrap"><h2>Hello, {user.name} <span className="tag">admin</span></h2>
    <Stats d={d} kind="admin" /><AdminPanel reload={reload} tick={tick} /><Notifications reload={reload} tick={tick} /></div>;
}
