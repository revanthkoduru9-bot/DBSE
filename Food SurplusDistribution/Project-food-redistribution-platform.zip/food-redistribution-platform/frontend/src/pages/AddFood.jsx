import { useState } from 'react'; import { useNavigate } from 'react-router-dom'; import api, { err } from '../services/api'; import { CATS } from '../components/FoodCard'; import toast from '../utils/toast';
const iso = v => new Date(v).toISOString(), D = ['prepared_at', 'consume_before', 'pickup_start', 'pickup_end'];
export default function AddFood() {
  const nav = useNavigate(), [f, setF] = useState({ category: CATS[0], unit: 'kg', food_type: 'veg' }), [img, setImg] = useState(null), [busy, setBusy] = useState(false);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const locate = () => navigator.geolocation?.getCurrentPosition(p => setF(x => ({ ...x, latitude: p.coords.latitude.toFixed(5), longitude: p.coords.longitude.toFixed(5) })), () => toast('Location permission denied', 1));
  const submit = async e => {
    e.preventDefault();
    if (new Date(f.consume_before) <= new Date()) return toast('Consume-before time must be in the future', 1);
    if (new Date(f.pickup_end) <= new Date(f.pickup_start)) return toast('Pickup end must be after pickup start', 1);
    const fd = new FormData(); Object.entries(f).forEach(([k, v]) => v !== '' && v != null && fd.append(k, D.includes(k) ? iso(v) : v)); if (img) fd.append('image', img);
    setBusy(true); try { await api.post('/food', fd); toast('Food donation listed!'); nav('/dashboard/donor'); } catch (x) { toast(err(x), 1); } setBusy(false);
  };
  const In = (k, l, p = {}) => <label>{l}<input required={!['description', 'latitude', 'longitude', 'instructions'].includes(k)} value={f[k] || ''} onChange={set(k)} {...p} /></label>;
  return <div className="wrap narrow"><form className="card pad form" onSubmit={submit}><h2>Add Food Donation</h2>
    {In('food_name', 'Food name')}<label>Category<select value={f.category} onChange={set('category')}>{CATS.map(c => <option key={c}>{c}</option>)}</select></label>
    <label>Description<textarea onChange={set('description')} /></label>
    <div className="row">{In('quantity', 'Quantity', { type: 'number', min: 1, step: 'any' })}<label>Unit<select value={f.unit} onChange={set('unit')}>{['kg', 'litres', 'packs', 'plates'].map(u => <option key={u}>{u}</option>)}</select></label>{In('servings', 'Serves (people)', { type: 'number', min: 1 })}</div>
    <label>Type<select value={f.food_type} onChange={set('food_type')}><option value="veg">Vegetarian</option><option value="non-veg">Non-vegetarian</option></select></label>
    {In('prepared_at', 'Prepared date & time', { type: 'datetime-local' })}{In('consume_before', 'Consume before', { type: 'datetime-local' })}
    {In('pickup_address', 'Pickup address')}<div className="row">{In('latitude', 'Latitude', { type: 'number', step: 'any' })}{In('longitude', 'Longitude', { type: 'number', step: 'any' })}<button type="button" className="btn alt" onClick={locate}>📍 Use my location</button></div>
    {In('pickup_start', 'Pickup start', { type: 'datetime-local' })}{In('pickup_end', 'Pickup end', { type: 'datetime-local' })}
    <label>Food image<input type="file" accept="image/*" onChange={e => setImg(e.target.files[0])} /></label><label>Special instructions<textarea onChange={set('instructions')} /></label>
    <button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Publish Donation'}</button></form></div>;
}
