import { useEffect, useState } from 'react'; import { Link } from 'react-router-dom'; import api from '../services/api'; import FoodCard from '../components/FoodCard';
const steps = [['🍲', 'Donate Surplus Food', 'Donors list extra food in minutes.'], ['✅', 'Food Verification', 'Admins verify donors and NGOs.'], ['🤝', 'NGO Requests Food', 'NGOs request what they can serve.'], ['🛵', 'Volunteer Pickup', 'Volunteers collect and deliver.'], ['🍛', 'Food Distribution', 'Food reaches people in need.'], ['🌱', 'Community Impact', 'Less waste, fewer hungry families.']];
const Steps = () => <div className="grid g3">{steps.map((s, i) => <div className="card pad center" key={i}><div className="ico">{s[0]}</div><h3>{i + 1}. {s[1]}</h3><p className="mut">{s[2]}</p></div>)}</div>;
export function Home() {
  const [st, setSt] = useState({}), [f, setF] = useState([]);
  useEffect(() => { api.get('/stats/public').then(r => setSt(r.data)).catch(() => {}); api.get('/food').then(r => setF(r.data.slice(0, 3))).catch(() => {}); }, []);
  const S = [['peopleServed', 'People served'], ['foodQty', 'Food units distributed'], ['donors', 'Donors'], ['ngos', 'NGOs'], ['volunteers', 'Volunteers']];
  return <>
    <section className="hero"><h1>Turn Surplus Food Into Hope</h1><p>Connecting surplus food with communities in need to reduce food waste and fight hunger.</p>
      <div><Link className="btn" to="/add-food">Donate Food</Link> <Link className="btn alt" to="/food">Find Food</Link></div></section>
    <div className="wrap"><h2>How it works</h2><Steps />
      <h2>Our impact</h2><div className="grid g5">{S.map(([k, l]) => <div className="card pad center" key={k}><div className="big">{st[k] ?? '–'}</div><div className="mut">{l}</div></div>)}</div>
      <h2>Featured donations</h2>{f.length ? <div className="grid g3">{f.map(x => <FoodCard key={x.id} f={x} />)}</div> : <p className="empty">No donations listed yet.</p>}
      <h2>Benefits</h2><div className="grid g3">{[['🌍', 'Less food waste', 'Surplus food is eaten, not dumped.'], ['❤️', 'Fights hunger', 'Meals reach nearby communities fast.'], ['⭐', 'Trusted network', 'Verified donors, NGOs and volunteers.']].map(b => <div className="card pad center" key={b[1]}><div className="ico">{b[0]}</div><h3>{b[1]}</h3><p className="mut">{b[2]}</p></div>)}</div>
      <h2>Testimonials</h2><div className="grid g2"><div className="card pad">“We used to throw away trays every night. Now they feed families the same evening.” — <b>Restaurant owner</b></div><div className="card pad">“Requesting and tracking food is simple, and volunteers are quick.” — <b>NGO coordinator</b></div></div></div></>;
}
export const About = () => <div className="wrap narrow"><h2>About Us</h2>
  <p>Around one-third of food produced is wasted, while many families go to bed hungry. Restaurants, hotels, supermarkets and events often have safe, edible surplus that never reaches anyone.</p>
  <p>Our platform lets donors list surplus food, admins verify participants, NGOs request it, and volunteers pick up and deliver it — all tracked end to end.</p>
  <p>The result: fewer meals wasted, fewer people hungry, and a smaller environmental footprint from landfill and methane emissions.</p></div>;
export const HowItWorks = () => <div className="wrap"><h2>How It Works</h2><Steps /></div>;
