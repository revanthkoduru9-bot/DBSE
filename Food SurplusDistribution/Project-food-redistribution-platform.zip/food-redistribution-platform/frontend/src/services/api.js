import axios from 'axios';
const api = axios.create({ baseURL: '/api' });
api.interceptors.request.use(c => { const t = localStorage.getItem('token'); if (t) c.headers.Authorization = 'Bearer ' + t; return c; });
// An expired/invalid token (401 on a normal call) logs the user out cleanly instead of leaving a half-working page.
api.interceptors.response.use(r => r, e => {
  const url = e.config?.url || '';
  if (e.response?.status === 401 && localStorage.getItem('token') && !/^\/auth\/(login|register)/.test(url)) {
    localStorage.removeItem('token'); if (location.pathname !== '/login') location.assign('/login');
  }
  return Promise.reject(e);
});
// Backend errors are always { "error": "..." } (older responses used "message", still tolerated).
export const err = e => e.response?.data?.error || e.response?.data?.message || (e.response ? 'Request failed (' + e.response.status + ')' : 'Cannot reach the server. Is the backend running?');
export default api;
