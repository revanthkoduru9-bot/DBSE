import { createContext, useContext, useEffect, useState } from 'react'; import api from '../services/api';
const C = createContext(); export const useAuth = () => useContext(C);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null), [caps, setCaps] = useState({ donor: false, ngo: false, volunteer: false }), [ready, setReady] = useState(false);
  const refresh = () => api.get('/auth/me').then(r => { setUser(r.data.user); setCaps(r.data.capabilities); }).catch(() => { localStorage.removeItem('token'); setUser(null); });
  useEffect(() => { if (!localStorage.getItem('token')) return setReady(true); refresh().finally(() => setReady(true)); }, []);
  const save = d => { localStorage.setItem('token', d.token); setUser(d.user); return refresh(); };
  const login = async b => save((await api.post('/auth/login', b)).data);
  const register = async b => save((await api.post('/auth/register', b)).data);
  const logout = () => { api.post('/auth/logout').catch(() => {}); localStorage.removeItem('token'); setUser(null); setCaps({ donor: false, ngo: false, volunteer: false }); };
  return <C.Provider value={{ user, caps, ready, login, register, logout, refresh }}>{children}</C.Provider>;
}
