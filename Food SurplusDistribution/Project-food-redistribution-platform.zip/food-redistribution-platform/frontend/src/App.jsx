import { Link, NavLink, Route, Routes, Navigate, useNavigate } from 'react-router-dom'; import { useAuth } from './context/Auth';
import { Home, About, HowItWorks } from './pages/Public'; import Food from './pages/Food'; import Auth from './pages/Auth';
import Dashboard, { Hub, DonorDashboard, NgoDashboard, VolunteerDashboard } from './pages/Dashboard'; import AddFood from './pages/AddFood';
function Guard({ children }) { const { user, ready } = useAuth(); if (!ready) return <p className="wrap">Loading…</p>; if (!user) return <Navigate to="/login" />; return children; }
// A single logged-in user lands on the Hub (pick Donate / NGO / Volunteer); an admin account
// goes straight to the platform-management dashboard instead.
function DashboardHome() { const { user } = useAuth(); return user.role === 'admin' ? <Dashboard /> : <Hub />; }
function Nav() {
  const { user, logout } = useAuth(), nav = useNavigate();
  return <header className="nav"><Link to="/" className="logo">🌾 FoodBridge</Link><nav>
    <NavLink to="/about">About</NavLink><NavLink to="/how-it-works">How It Works</NavLink><NavLink to="/food">Available Food</NavLink>
    {user ? <><NavLink to="/dashboard">Dashboard</NavLink><a href="#" onClick={e => { e.preventDefault(); logout(); nav('/'); }}>Logout</a></> : <><NavLink to="/login">Login</NavLink><Link className="btn sm" to="/register">Register</Link></>}</nav></header>;
}
export default function App() {
  return <><Nav /><main><Routes>
    <Route path="/" element={<Home />} /><Route path="/about" element={<About />} /><Route path="/how-it-works" element={<HowItWorks />} /><Route path="/food" element={<Food />} />
    <Route path="/login" element={<Auth mode="login" />} /><Route path="/register" element={<Auth mode="register" />} />
    <Route path="/dashboard" element={<Guard><DashboardHome /></Guard>} />
    <Route path="/dashboard/donor" element={<Guard><DonorDashboard /></Guard>} />
    <Route path="/dashboard/ngo" element={<Guard><NgoDashboard /></Guard>} />
    <Route path="/dashboard/volunteer" element={<Guard><VolunteerDashboard /></Guard>} />
    <Route path="/add-food" element={<Guard><AddFood /></Guard>} />
    <Route path="*" element={<p className="wrap empty">Page not found.</p>} /></Routes></main>
    <footer className="foot">© 2026 FoodBridge — Food Surplus Redistribution & Community Hunger Reduction Platform</footer></>;
}
