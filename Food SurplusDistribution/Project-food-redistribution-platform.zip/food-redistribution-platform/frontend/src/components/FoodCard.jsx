export const CATS = ['Cooked Meals', 'Bakery', 'Fruits & Vegetables', 'Packaged Food', 'Dairy', 'Snacks', 'Other'];
const t = d => new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
export default function FoodCard({ f, onRequest }) {
  return <div className="card">
    {f.image_url ? <img src={f.image_url} alt={f.food_name} /> : <div className="ph">🍲</div>}
    <div className="pad">
      <span className="tag">{f.category}</span> <span className={'tag ' + (f.food_type === 'veg' ? '' : 'o')}>{f.food_type === 'veg' ? 'Veg' : 'Non-veg'}</span>
      <h3>{f.food_name}</h3><p className="mut">{f.quantity} {f.unit} · serves {f.servings}</p>
      <p>📍 {f.pickup_address}{f.distance_km != null && ` (${f.distance_km} km)`}</p>
      <p className="mut">Posted {t(f.created_at)}<br />Consume before {t(f.consume_before)}<br />By {f.Donor?.organization_name}</p>
      {onRequest && f.status === 'available' && <button className="btn" onClick={() => onRequest(f)}>Request Food</button>}
    </div></div>;
}
