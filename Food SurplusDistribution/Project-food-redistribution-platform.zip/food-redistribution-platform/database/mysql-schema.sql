-- Tables are created automatically by Sequelize (sequelize.sync) the first time the
-- backend starts (see backend/config/db.js and backend/models/index.js). This file is
-- provided for reference / manual setup and mirrors that schema exactly.

CREATE DATABASE IF NOT EXISTS food_redistribution;
USE food_redistribution;

-- A single row per registered account. 'role' only distinguishes a platform admin from an
-- ordinary user - it is NOT "donor/ngo/volunteer" anymore. One user row can have a Donor,
-- an Ngo and a Volunteer profile at the same time (see below), so there is only ever one
-- registration and one login per person, however many of the three activities they use.
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  address VARCHAR(255),
  city VARCHAR(100),
  state VARCHAR(100),
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  status ENUM('active','blocked') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL
);

-- Optional capability profiles. Each is created automatically (seeded from the user's own
-- name/address) the first time that user donates food / requests food / accepts a pickup, or
-- earlier if they fill in the "Edit profile" form on that section of the dashboard. A user_id
-- may appear in zero, one, two or all three of these tables.
CREATE TABLE IF NOT EXISTS donors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  organization_name VARCHAR(255),
  address VARCHAR(255),
  city VARCHAR(100),
  state VARCHAR(100),
  latitude DOUBLE,
  longitude DOUBLE,
  verification_status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ngos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  organization_name VARCHAR(255),
  registration_number VARCHAR(100),
  address VARCHAR(255),
  city VARCHAR(100),
  state VARCHAR(100),
  service_area VARCHAR(255),
  verification_status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS volunteers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  availability VARCHAR(255),
  address VARCHAR(255),
  latitude DOUBLE,
  longitude DOUBLE,
  verification_status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS food_listings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT NOT NULL,
  food_name VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  description TEXT,
  quantity DOUBLE,
  unit VARCHAR(50),
  servings INT,
  prepared_at DATETIME,
  consume_before DATETIME,
  food_type ENUM('veg','non-veg'),
  image_url VARCHAR(255),
  pickup_address VARCHAR(255),
  latitude DOUBLE,
  longitude DOUBLE,
  pickup_start DATETIME,
  pickup_end DATETIME,
  instructions TEXT,
  status ENUM('available','requested','completed','removed') NOT NULL DEFAULT 'available',
  created_at DATETIME NOT NULL,
  FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
  INDEX idx_food_listings_status (status),
  INDEX idx_food_listings_consume_before (consume_before)
);

CREATE TABLE IF NOT EXISTS food_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  food_listing_id INT NOT NULL,
  ngo_id INT NOT NULL,
  requested_quantity DOUBLE,
  requested_servings INT,
  preferred_pickup_time DATETIME,
  message TEXT,
  status ENUM('pending','approved','rejected','accepted','picked_up','delivered','completed','cancelled') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL,
  FOREIGN KEY (food_listing_id) REFERENCES food_listings(id) ON DELETE CASCADE,
  FOREIGN KEY (ngo_id) REFERENCES ngos(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS pickup_tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  food_request_id INT NOT NULL UNIQUE,
  volunteer_id INT,
  pickup_time DATETIME,
  pickup_status ENUM('open','accepted','picked_up') NOT NULL DEFAULT 'open',
  delivery_status ENUM('pending','delivered') NOT NULL DEFAULT 'pending',
  completed_at DATETIME,
  FOREIGN KEY (food_request_id) REFERENCES food_requests(id) ON DELETE CASCADE,
  FOREIGN KEY (volunteer_id) REFERENCES volunteers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS distributions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  food_request_id INT NOT NULL UNIQUE,
  food_quantity DOUBLE,
  people_served INT,
  distributed_at DATETIME,
  confirmation_status VARCHAR(50) DEFAULT 'confirmed',
  FOREIGN KEY (food_request_id) REFERENCES food_requests(id) ON DELETE CASCADE
);

-- Replaces what used to be MongoDB collections: now plain MySQL tables.
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type VARCHAR(50),
  title VARCHAR(255),
  message TEXT,
  related_id INT,
  `read` BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notifications_user (user_id)
);

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  action VARCHAR(100),
  entity VARCHAR(100),
  entity_id INT,
  description TEXT,
  metadata JSON,
  created_at DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_activity_logs_user (user_id),
  INDEX idx_activity_logs_entity (entity, entity_id)
);

CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  donation_id INT,
  rating INT NOT NULL,
  comment TEXT,
  created_at DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  message TEXT NOT NULL,
  `read` BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME NOT NULL,
  FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_messages_sender (sender_id),
  INDEX idx_messages_receiver (receiver_id)
);
