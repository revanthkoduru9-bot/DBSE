const { Sequelize, DataTypes } = require('sequelize');
const mysql = require('mysql2/promise');
const { REQUEST_VALUES } = require('../utils/status');
const e = process.env;
const sequelize = new Sequelize(e.MYSQL_DATABASE, e.MYSQL_USER, e.MYSQL_PASSWORD || '', { host: e.MYSQL_HOST, dialect: 'mysql', logging: false, define: { underscored: true } });

// Sequelize's `sync({ alter: true })` rewrites a MySQL ENUM column by issuing a direct
// `MODIFY COLUMN` against whatever is CURRENTLY stored - if the table still has rows left
// over from an earlier version of this project (role = 'donor' / 'ngo' / 'volunteer'), MySQL
// cannot fit those into the new ENUM('admin','user') and throws "Data truncated for column
// 'role'" before the app can even start. `alter: true` is unreliable for ENUM columns in
// general, so instead of using it we run one explicit, predictable migration here: normalise
// any legacy values FIRST, then narrow the column ourselves, then create (only) whatever
// tables don't exist yet with a plain sync(). This is idempotent and safe to run on every boot.
async function migrateUsersTable() {
  const qi = sequelize.getQueryInterface();
  const tables = (await qi.showAllTables()).map(String);
  if (!tables.includes('users')) return; // fresh database - sync() below creates it correctly

  const desc = await qi.describeTable('users');
  for (const col of ['address', 'city', 'state']) {
    if (!desc[col]) { await qi.addColumn('users', col, { type: DataTypes.STRING, allowNull: true }); console.log(`[migrate] added missing column users.${col}`); }
  }

  const m = desc.role && /^enum\(([^)]*)\)$/i.exec(String(desc.role.type).trim());
  const current = m ? m[1].split(',').map(v => v.trim().replace(/^'(.*)'$/, '$1')) : null;
  if (!current || current.join(',') !== 'admin,user') {
    // Classic widen -> normalise -> narrow migration. We cannot UPDATE any row to 'user' until
    // 'user' is itself a legal value for the CURRENT enum (e.g. an old enum('admin','donor',
    // 'ngo','volunteer') column does not allow 'user' yet) - trying to skip straight to the
    // final two-value enum is exactly what causes "Data truncated for column 'role'".
    const widened = Array.from(new Set([...(current || []), 'admin', 'user']));
    await sequelize.query(`ALTER TABLE \`users\` MODIFY COLUMN \`role\` ENUM(${widened.map(v => `'${v}'`).join(',')}) NOT NULL DEFAULT 'user'`);
    // Any account whose role is not one of the two final valid values (leftover donor/ngo/
    // volunteer rows from an earlier schema) becomes a normal 'user' - it keeps its own row and
    // any donor/ngo/volunteer PROFILE rows it already has untouched; only this label changes.
    const [result] = await sequelize.query("UPDATE `users` SET `role` = 'user' WHERE `role` NOT IN ('admin','user')");
    if (result?.affectedRows) console.log(`[migrate] normalised ${result.affectedRows} user(s) with a legacy role value to 'user'`);
    await sequelize.query("ALTER TABLE `users` MODIFY COLUMN `role` ENUM('admin','user') NOT NULL DEFAULT 'user'");
    console.log("[migrate] users.role is now ENUM('admin','user')");
  }
}

// Request statuses are now one consistent lowercase vocabulary (see utils/status.js). Older databases
// still have the legacy value 'pickup_assigned' in food_requests.status; it is now called 'accepted'.
// Same safe widen -> normalise -> narrow approach as above: no rows are deleted, only the label changes.
async function migrateRequestStatus() {
  const qi = sequelize.getQueryInterface();
  const tables = (await qi.showAllTables()).map(String);
  if (!tables.includes('food_requests')) return; // fresh database - sync() creates it correctly
  const desc = await qi.describeTable('food_requests');
  const m = desc.status && /^enum\(([^)]*)\)$/i.exec(String(desc.status.type).trim());
  const current = m ? m[1].split(',').map(v => v.trim().replace(/^'(.*)'$/, '$1')) : [];
  const same = current.length === REQUEST_VALUES.length && REQUEST_VALUES.every(v => current.includes(v));
  if (same) return;
  const widened = Array.from(new Set([...current, ...REQUEST_VALUES]));
  const list = a => a.map(v => `'${v}'`).join(',');
  await sequelize.query(`ALTER TABLE \`food_requests\` MODIFY COLUMN \`status\` ENUM(${list(widened)}) NOT NULL DEFAULT 'pending'`);
  const [r] = await sequelize.query("UPDATE `food_requests` SET `status` = 'accepted' WHERE `status` = 'pickup_assigned'");
  if (r?.affectedRows) console.log(`[migrate] renamed ${r.affectedRows} request(s) from 'pickup_assigned' to 'accepted'`);
  await sequelize.query(`ALTER TABLE \`food_requests\` MODIFY COLUMN \`status\` ENUM(${list(REQUEST_VALUES)}) NOT NULL DEFAULT 'pending'`);
  console.log('[migrate] food_requests.status is now ENUM(' + REQUEST_VALUES.join(',') + ')');
}

const connect = async () => {
  const c = await mysql.createConnection({ host: e.MYSQL_HOST, user: e.MYSQL_USER, password: e.MYSQL_PASSWORD || '' });
  await c.query(`CREATE DATABASE IF NOT EXISTS \`${e.MYSQL_DATABASE}\``); await c.end();
  require('../models');
  await migrateUsersTable();
  await migrateRequestStatus();
  await sequelize.sync(); // creates any missing tables; never rewrites an existing table's columns
};
module.exports = { sequelize, connect };
