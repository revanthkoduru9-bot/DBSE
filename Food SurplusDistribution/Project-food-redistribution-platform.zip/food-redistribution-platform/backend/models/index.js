const { DataTypes: T } = require('sequelize');
const { sequelize: s } = require('../config/db');
const { REQUEST_VALUES, LISTING_VALUES } = require('../utils/status');
const V = { type: T.ENUM('pending', 'verified', 'rejected'), defaultValue: 'pending' };
const P = { timestamps: false };
// A single account can hold any combination of a Donor, Ngo and Volunteer profile (see associations
// below) - 'role' now only distinguishes platform admins from ordinary registered users.
const User = s.define('User', { name: T.STRING, email: { type: T.STRING, unique: true }, password: T.STRING, phone: T.STRING, address: T.STRING, city: T.STRING, state: T.STRING, role: { type: T.ENUM('admin', 'user'), allowNull: false, defaultValue: 'user' }, status: { type: T.ENUM('active', 'blocked'), defaultValue: 'active' } }, { tableName: 'users' });
const Donor = s.define('Donor', { organization_name: T.STRING, address: T.STRING, city: T.STRING, state: T.STRING, latitude: T.DOUBLE, longitude: T.DOUBLE, verification_status: V }, { ...P, tableName: 'donors' });
const Ngo = s.define('Ngo', { organization_name: T.STRING, registration_number: T.STRING, address: T.STRING, city: T.STRING, state: T.STRING, service_area: T.STRING, verification_status: V }, { ...P, tableName: 'ngos' });
const Volunteer = s.define('Volunteer', { availability: T.STRING, address: T.STRING, latitude: T.DOUBLE, longitude: T.DOUBLE, verification_status: V }, { ...P, tableName: 'volunteers' });
const FoodListing = s.define('FoodListing', { food_name: T.STRING, category: T.STRING, description: T.TEXT, quantity: T.DOUBLE, unit: T.STRING, servings: T.INTEGER, prepared_at: T.DATE, consume_before: T.DATE, food_type: T.ENUM('veg', 'non-veg'), image_url: T.STRING, pickup_address: T.STRING, latitude: T.DOUBLE, longitude: T.DOUBLE, pickup_start: T.DATE, pickup_end: T.DATE, instructions: T.TEXT, status: { type: T.ENUM(...LISTING_VALUES), defaultValue: 'available' } }, { tableName: 'food_listings', updatedAt: false, indexes: [{ fields: ['status'] }, { fields: ['consume_before'] }] });
const FoodRequest = s.define('FoodRequest', { requested_quantity: T.DOUBLE, requested_servings: T.INTEGER, preferred_pickup_time: T.DATE, message: T.TEXT, status: { type: T.ENUM(...REQUEST_VALUES), defaultValue: 'pending' } }, { tableName: 'food_requests', updatedAt: false });
const PickupTask = s.define('PickupTask', { pickup_time: T.DATE, pickup_status: { type: T.ENUM('open', 'accepted', 'picked_up'), defaultValue: 'open' }, delivery_status: { type: T.ENUM('pending', 'delivered'), defaultValue: 'pending' }, completed_at: T.DATE }, { tableName: 'pickup_tasks', timestamps: false });
const Distribution = s.define('Distribution', { food_quantity: T.DOUBLE, people_served: T.INTEGER, distributed_at: T.DATE, confirmation_status: { type: T.STRING, defaultValue: 'confirmed' } }, { tableName: 'distributions', timestamps: false });

// Previously MongoDB collections, now plain MySQL/Sequelize tables.
const Notification = s.define('Notification', { user_id: { type: T.INTEGER, allowNull: false }, type: T.STRING, title: T.STRING, message: T.TEXT, related_id: T.INTEGER, read: { type: T.BOOLEAN, defaultValue: false } }, { tableName: 'notifications', updatedAt: false, indexes: [{ fields: ['user_id'] }] });
const ActivityLog = s.define('ActivityLog', { user_id: T.INTEGER, action: T.STRING, entity: T.STRING, entity_id: T.INTEGER, description: T.TEXT, metadata: T.JSON }, { tableName: 'activity_logs', updatedAt: false, indexes: [{ fields: ['user_id'] }, { fields: ['entity', 'entity_id'] }] });
const Feedback = s.define('Feedback', { user_id: { type: T.INTEGER, allowNull: false }, donation_id: T.INTEGER, rating: { type: T.INTEGER, allowNull: false, validate: { min: 1, max: 5 } }, comment: T.TEXT }, { tableName: 'feedback', updatedAt: false });
const Message = s.define('Message', { sender_id: { type: T.INTEGER, allowNull: false }, receiver_id: { type: T.INTEGER, allowNull: false }, message: { type: T.TEXT, allowNull: false }, read: { type: T.BOOLEAN, defaultValue: false } }, { tableName: 'messages', updatedAt: false, indexes: [{ fields: ['sender_id'] }, { fields: ['receiver_id'] }] });

// Every association has an EXPLICIT, UNIQUE alias (`as`). The alias of each belongsTo/hasOne/hasMany
// is the same string every include in routes/api.js uses, so Sequelize never has to guess and two
// associations to the same model (User <- Donor / Ngo / Volunteer) can never collide.
const rel = (A, B, fk, { one = false, asA, asB } = {}) => {
  A[one ? 'hasOne' : 'hasMany'](B, { foreignKey: fk, as: asA });
  B.belongsTo(A, { foreignKey: fk, as: asB });
};
rel(User, Donor, 'user_id', { one: true, asA: 'Donor', asB: 'User' });
rel(User, Ngo, 'user_id', { one: true, asA: 'Ngo', asB: 'User' });
rel(User, Volunteer, 'user_id', { one: true, asA: 'Volunteer', asB: 'User' });
rel(Donor, FoodListing, 'donor_id', { asA: 'FoodListings', asB: 'Donor' });
rel(FoodListing, FoodRequest, 'food_listing_id', { asA: 'FoodRequests', asB: 'FoodListing' });
rel(Ngo, FoodRequest, 'ngo_id', { asA: 'FoodRequests', asB: 'Ngo' });
rel(FoodRequest, PickupTask, 'food_request_id', { one: true, asA: 'PickupTask', asB: 'FoodRequest' });
rel(Volunteer, PickupTask, 'volunteer_id', { asA: 'PickupTasks', asB: 'Volunteer' });
rel(FoodRequest, Distribution, 'food_request_id', { one: true, asA: 'Distribution', asB: 'FoodRequest' });
rel(User, Notification, 'user_id', { asA: 'Notifications', asB: 'User' });
rel(User, ActivityLog, 'user_id', { asA: 'ActivityLogs', asB: 'User' });
rel(User, Feedback, 'user_id', { asA: 'Feedbacks', asB: 'User' });
module.exports = { sequelize: s, User, Donor, Ngo, Volunteer, FoodListing, FoodRequest, PickupTask, Distribution, Notification, ActivityLog, Feedback, Message };
