// ---------------------------------------------------------------------------
// Single source of truth for every status value and every allowed transition.
// Backend representation is ALWAYS lowercase; the frontend maps these to labels.
// ---------------------------------------------------------------------------
const REQUEST = Object.freeze({
  PENDING: 'pending', APPROVED: 'approved', REJECTED: 'rejected', CANCELLED: 'cancelled',
  ACCEPTED: 'accepted', PICKED_UP: 'picked_up', DELIVERED: 'delivered', COMPLETED: 'completed',
});
// A listing has its OWN, separate lifecycle (never mixed with the request lifecycle).
const LISTING = Object.freeze({ AVAILABLE: 'available', REQUESTED: 'requested', COMPLETED: 'completed', REMOVED: 'removed' });

const REQUEST_VALUES = Object.values(REQUEST);
const LISTING_VALUES = Object.values(LISTING);
// A request in one of these states still "holds" its food listing.
const ACTIVE_REQUEST = [REQUEST.PENDING, REQUEST.APPROVED, REQUEST.ACCEPTED, REQUEST.PICKED_UP, REQUEST.DELIVERED];

// TRANSITIONS[from][to] = roles that are allowed to perform that transition.
//   donor     -> owner of the food listing        ngo   -> owner of the request
//   volunteer -> the volunteer holding the pickup  admin -> platform admin
const TRANSITIONS = {
  pending:   { approved: ['donor', 'admin'], rejected: ['donor', 'admin'], cancelled: ['ngo', 'admin'] },
  approved:  { accepted: ['volunteer'], cancelled: ['ngo', 'admin'] },
  accepted:  { picked_up: ['volunteer'] },
  picked_up: { delivered: ['volunteer'] },
  delivered: { completed: ['ngo'] },
  rejected: {}, cancelled: {}, completed: {},
};

const E = (status, message) => Object.assign(new Error(message), { status });

// Throws an HTTP-style error (409 = impossible transition, 403 = wrong actor) or returns quietly.
// `actors` is the LIST of roles the caller holds for this request (one account can be donor,
// NGO, volunteer and admin at once), so being one role never hides the permissions of another.
function assertTransition(from, to, actors) {
  if (!REQUEST_VALUES.includes(to)) throw E(400, `Invalid status "${to}"`);
  if (from === to) throw E(409, `Request is already ${from}`);
  const allowed = (TRANSITIONS[from] || {})[to];
  if (!allowed) throw E(409, `Cannot change status from ${from} to ${to}`);
  if (!actors.some(a => allowed.includes(a))) throw E(403, `You are not allowed to change status from ${from} to ${to}`);
}

module.exports = { REQUEST, LISTING, REQUEST_VALUES, LISTING_VALUES, ACTIVE_REQUEST, TRANSITIONS, assertTransition, E };
