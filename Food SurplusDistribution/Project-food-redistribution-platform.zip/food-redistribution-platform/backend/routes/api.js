const r = require('express').Router();
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), multer = require('multer'), path = require('path');
const { Op, fn, col } = require('sequelize');
const { sequelize, User, Donor, Ngo, Volunteer, FoodListing: FL, FoodRequest: FR, PickupTask: PT, Distribution, Notification, ActivityLog, Feedback } = require('../models');
const { REQUEST: RS, LISTING: LS, REQUEST_VALUES, ACTIVE_REQUEST, assertTransition } = require('../utils/status');
const { auth, role } = require('../middleware/auth');
const upload = multer({ storage: multer.diskStorage({ destination: path.join(__dirname, '../uploads'), filename: (q, f, cb) => cb(null, Date.now() + path.extname(f.originalname).toLowerCase()) }), limits: { fileSize: 3e6 }, fileFilter: (q, f, cb) => cb(null, /^image\//.test(f.mimetype)) });
const h = f => (q, s, n) => f(q, s, n).catch(n);
const E = (st, m) => Object.assign(new Error(m), { status: st });
const intPos = v => Number.isInteger(+v) && +v > 0;
const need = (b, ...f) => { const m = f.filter(k => b[k] === undefined || b[k] === ''); if (m.length) throw E(400, 'Missing required: ' + m.join(', ')); };
const notify = (user_id, type, title, message, related_id) => Notification.create({ user_id, type, title, message, related_id }).catch(() => {});
const log = (q, action, entity, entity_id, description) => ActivityLog.create({ user_id: q.user.id, action, entity, entity_id, description }).catch(() => {});
// Include definitions are FACTORIES returning brand-new objects on every call. Sequelize mutates the
// include objects it is given (it writes `as`, `parent`, `association`... onto them), so sharing one
// object in two places of the same query - the old `U` constant used under both Donor and Ngo - made it
// emit a broken join list ("Not unique table/alias: 'Ngo->User'"). Aliases match models/index.js exactly.
const userInc = () => ({ model: User, as: 'User', attributes: ['id', 'name', 'phone', 'email'] });
const donorInc = () => ({ model: Donor, as: 'Donor', include: [userInc()] });
const listingInc = () => ({ model: FL, as: 'FoodListing', include: [donorInc()] });
const ngoInc = () => ({ model: Ngo, as: 'Ngo', include: [userInc()] });
const tok = u => jwt.sign({ id: u.id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const safe = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, phone: u.phone, address: u.address, city: u.city, state: u.state });
const km = (a, b, c, d) => { const t = x => x * Math.PI / 180, x = Math.sin(t(c - a) / 2) ** 2 + Math.cos(t(a)) * Math.cos(t(c)) * Math.sin(t(d - b) / 2) ** 2; return 12742 * Math.asin(Math.sqrt(x)); };

// One account can hold a Donor, an Ngo and a Volunteer profile simultaneously (each is just a
// row in its own table keyed by user_id). getProfile() looks one up without creating it;
// ensureProfile() creates it on first use, seeded from the user's own details, so nobody is
// ever asked to "register" again for a capability they haven't used yet.
const PMAP = { donor: Donor, ngo: Ngo, volunteer: Volunteer };
const getProfile = (type, userId) => PMAP[type].findOne({ where: { user_id: userId } });
const ensureProfile = async (type, user, defaults = {}) => {
  let p = await getProfile(type, user.id);
  if (!p) p = await PMAP[type].create({ user_id: user.id, address: user.address, city: user.city, state: user.state, verification_status: 'pending', ...defaults });
  return p;
};
const verified = p => { if (process.env.REQUIRE_VERIFICATION === 'true' && p.verification_status !== 'verified') throw E(403, 'Your account is awaiting admin verification for this activity'); };

// ---- Auth (single registration / single login for every capability)
r.post('/auth/register', h(async (q, s) => {
  const b = q.body; need(b, 'name', 'email', 'password');
  if (String(b.password).length < 6) throw E(400, 'Password must be at least 6 characters');
  if (!/^\S+@\S+\.\S+$/.test(b.email)) throw E(400, 'Invalid email address');
  if (await User.findOne({ where: { email: String(b.email) } })) throw E(400, 'Email already registered');
  const u = await User.create({ name: b.name, email: b.email, phone: b.phone, address: b.address, city: b.city, state: b.state, role: 'user', password: await bcrypt.hash(String(b.password), 10) });
  s.status(201).json({ token: tok(u), user: safe(u) });
}));
r.post('/auth/login', h(async (q, s) => {
  need(q.body, 'email', 'password');
  const u = await User.findOne({ where: { email: String(q.body.email) } });
  if (!u || !(await bcrypt.compare(String(q.body.password), u.password))) throw E(401, 'Invalid email or password');
  if (u.status !== 'active') throw E(403, 'Your account has been blocked');
  s.json({ token: tok(u), user: safe(u) });
}));
r.get('/auth/me', auth, h(async (q, s) => {
  const [d, n, v] = await Promise.all([getProfile('donor', q.user.id), getProfile('ngo', q.user.id), getProfile('volunteer', q.user.id)]);
  s.json({ user: safe(q.user), capabilities: { donor: !!d, ngo: !!n, volunteer: !!v } });
}));
r.post('/auth/logout', auth, (q, s) => s.json({ message: 'Logged out' }));

// ---- Profiles (optional, per-capability details any logged-in user can view/edit)
const PFIELDS = { donor: ['organization_name', 'address', 'city', 'state', 'latitude', 'longitude'], ngo: ['organization_name', 'registration_number', 'address', 'city', 'state', 'service_area'], volunteer: ['availability', 'address', 'city', 'state', 'latitude', 'longitude'] };
r.get('/profile/:type', auth, h(async (q, s) => { if (!PMAP[q.params.type]) throw E(400, 'Unknown profile type'); s.json(await getProfile(q.params.type, q.user.id)); }));
r.put('/profile/:type', auth, h(async (q, s) => {
  const type = q.params.type; if (!PMAP[type]) throw E(400, 'Unknown profile type');
  const p = await ensureProfile(type, q.user);
  const b = {}; PFIELDS[type].forEach(k => { if (q.body[k] !== undefined) b[k] = q.body[k]; });
  await p.update(b); log(q, 'update', type + '_profile', p.id, 'Updated ' + type + ' profile'); s.json(p);
}));

// ---- Food (donor capability)
const listInc = () => [{ model: Donor, as: 'Donor', attributes: ['id', 'organization_name', 'city'] }];
r.get('/food', h(async (q, s) => {
  const { q: text, category, food_type, min_quantity, location, lat, lng, radius, availability } = q.query, w = {}, and = [];
  if (availability !== 'all') { w.status = 'available'; w.consume_before = { [Op.gt]: new Date() }; } else w.status = { [Op.ne]: 'removed' };
  if (category) w.category = String(category); if (food_type) w.food_type = String(food_type);
  if (min_quantity) w.quantity = { [Op.gte]: Number(min_quantity) };
  if (text) and.push({ [Op.or]: [{ food_name: { [Op.like]: `%${text}%` } }, { description: { [Op.like]: `%${text}%` } }] });
  if (location) and.push({ pickup_address: { [Op.like]: `%${location}%` } });
  if (and.length) w[Op.and] = and;
  let rows = (await FL.findAll({ where: w, include: listInc(), order: [['created_at', 'DESC']] })).map(x => x.toJSON());
  if (lat && lng) {
    rows.forEach(x => x.distance_km = x.latitude ? +km(+lat, +lng, x.latitude, x.longitude).toFixed(1) : null);
    if (radius) rows = rows.filter(x => x.distance_km != null && x.distance_km <= +radius);
    rows.sort((a, b) => (a.distance_km ?? 1e9) - (b.distance_km ?? 1e9));
  }
  s.json(rows);
}));
r.get('/food/mine', auth, h(async (q, s) => { const d = await getProfile('donor', q.user.id); s.json(d ? await FL.findAll({ where: { donor_id: d.id }, order: [['created_at', 'DESC']] }) : []); }));
r.get('/food/:id', h(async (q, s) => { const f = await FL.findByPk(q.params.id, { include: listInc() }); if (!f) throw E(404, 'Listing not found'); s.json(f); }));
r.post('/food', auth, upload.single('image'), h(async (q, s) => {
  const b = q.body; need(b, 'food_name', 'category', 'quantity', 'unit', 'servings', 'prepared_at', 'consume_before', 'food_type', 'pickup_address', 'pickup_start', 'pickup_end');
  if (new Date(b.consume_before) <= new Date()) throw E(400, 'Consume-before time must be in the future');
  if (new Date(b.pickup_end) <= new Date(b.pickup_start)) throw E(400, 'Pickup end must be after pickup start');
  if (+b.quantity <= 0 || +b.servings <= 0) throw E(400, 'Quantity and servings must be positive');
  const donor = await ensureProfile('donor', q.user, { organization_name: q.user.name });
  verified(donor);
  const f = await FL.create({ ...b, id: undefined, status: 'available', donor_id: donor.id, image_url: q.file ? '/uploads/' + q.file.filename : null, latitude: b.latitude || null, longitude: b.longitude || null });
  (await Ngo.findAll()).forEach(n => notify(n.user_id, 'new_food', 'New food donation', `${f.food_name} at ${f.pickup_address}`, f.id));
  log(q, 'create', 'food_listing', f.id, 'Created listing ' + f.food_name);
  s.status(201).json(f);
}));
const own = async q => { const f = await FL.findByPk(q.params.id); if (!f) throw E(404, 'Listing not found'); if (q.user.role !== 'admin') { const d = await getProfile('donor', q.user.id); if (!d || f.donor_id !== d.id) throw E(403, 'Not your listing'); } return f; };
r.put('/food/:id', auth, h(async (q, s) => { const f = await own(q); const { id, donor_id, status, ...b } = q.body; await f.update(b); log(q, 'update', 'food_listing', f.id, 'Updated listing'); s.json(f); }));
r.delete('/food/:id', auth, h(async (q, s) => { const f = await own(q); if (f.status !== LS.AVAILABLE) throw E(409, `A listing that is ${f.status} cannot be removed`); await f.update({ status: LS.REMOVED }); log(q, 'remove', 'food_listing', f.id, 'Removed listing'); s.json({ message: 'Listing removed' }); }));

// ---- Requests (ngo capability to request, donor capability to approve)
// Request status and listing status are two separate lifecycles (utils/status.js). A request only ever
// writes food_requests.status; the listing's own status is changed explicitly and only when needed
// ('requested' while a request holds it, back to 'available' if released, 'completed' at the end).
const rInc = () => [listingInc(), ngoInc(), { model: PT, as: 'PickupTask' }];
// Which roles does THIS logged-in account hold for THIS request? One account can be donor + NGO +
// volunteer + admin at once, so this returns every role that applies, not just the first one found.
const rolesFor = async (user, x, f, t) => {
  const roles = [];
  if (user.role === 'admin') roles.push('admin');
  const [donor, ngo, vol] = await Promise.all([getProfile('donor', user.id), getProfile('ngo', user.id), getProfile('volunteer', user.id)]);
  if (donor && f.donor_id === donor.id) roles.push('donor');
  if (ngo && x.ngo_id === ngo.id) roles.push('ngo');
  const pt = x.PickupTask || await PT.findOne({ where: { food_request_id: x.id }, transaction: t });
  if (vol && pt && pt.volunteer_id === vol.id) roles.push('volunteer');
  return roles;
};
const lock = t => ({ transaction: t, lock: t.LOCK.UPDATE });

r.post('/requests', auth, h(async (q, s) => {
  const b = q.body; need(b, 'food_listing_id', 'requested_quantity', 'requested_servings');
  if (!(+b.requested_quantity > 0)) throw E(400, 'Requested quantity must be greater than 0');
  if (!intPos(b.requested_servings)) throw E(400, 'People to serve must be a whole number greater than 0');
  const ngo = await ensureProfile('ngo', q.user, { organization_name: q.user.name });
  verified(ngo);
  const { x, f, donor } = await sequelize.transaction(async t => {
    const f = await FL.findByPk(b.food_listing_id, lock(t)); // row lock: two NGOs cannot both grab the same listing
    if (!f || f.status === LS.REMOVED) throw E(404, 'Food listing not found');
    if (f.status !== LS.AVAILABLE) throw E(409, 'This food is no longer available');
    if (new Date(f.consume_before) <= new Date()) throw E(409, 'This food has expired');
    if (+b.requested_quantity > f.quantity) throw E(400, 'Requested quantity must be between 1 and ' + f.quantity);
    const x = await FR.create({ food_listing_id: f.id, ngo_id: ngo.id, requested_quantity: b.requested_quantity, requested_servings: b.requested_servings, preferred_pickup_time: b.preferred_pickup_time || null, message: b.message, status: RS.PENDING }, { transaction: t });
    await f.update({ status: LS.REQUESTED }, { transaction: t }); // listing keeps its donor_id untouched
    return { x, f, donor: await Donor.findByPk(f.donor_id, { transaction: t }) };
  });
  notify(donor.user_id, 'request', 'New food request', `${ngo.organization_name} requested ${f.food_name}`, x.id);
  log(q, 'create', 'food_request', x.id, 'Requested ' + f.food_name);
  s.status(201).json(x);
}));
// ?view=donor returns requests against my food listings; ?view=ngo returns requests I sent as an NGO.
r.get('/requests', auth, h(async (q, s) => {
  const view = q.query.view === 'donor' ? 'donor' : 'ngo', inc = rInc(), where = {};
  if (view === 'ngo') { const ngo = await getProfile('ngo', q.user.id); where.ngo_id = ngo ? ngo.id : -1; }
  else { const donor = await getProfile('donor', q.user.id); inc[0] = { ...inc[0], where: { donor_id: donor ? donor.id : -1 }, required: true }; }
  s.json(await FR.findAll({ where, include: inc, order: [['created_at', 'DESC']] }));
}));
r.get('/requests/:id', auth, h(async (q, s) => {
  const x = await FR.findByPk(q.params.id, { include: rInc() }); if (!x) throw E(404, 'Request not found');
  if (q.user.role !== 'admin' && !(await rolesFor(q.user, x, x.FoodListing)).length) throw E(403, 'This request does not belong to you');
  s.json(x);
}));

// Donor: pending -> approved / rejected. NGO: pending|approved -> cancelled, delivered -> completed.
// Admin: as defined in utils/status.js. (Volunteer steps live under /pickups.) Every rule is in TRANSITIONS.
r.put('/requests/:id/status', auth, h(async (q, s) => {
  const to = String(q.body.status || '').trim().toLowerCase();
  if (!REQUEST_VALUES.includes(to)) throw E(400, 'Invalid status. Use one of: ' + REQUEST_VALUES.join(', '));
  const out = await sequelize.transaction(async t => {
    const x = await FR.findByPk(q.params.id, lock(t)); if (!x) throw E(404, 'Request not found');
    const f = await FL.findByPk(x.food_listing_id, lock(t));
    const roles = await rolesFor(q.user, x, f, t);
    if (!roles.length) throw E(403, 'This request does not belong to you');
    assertTransition(x.status, to, roles); // 409 if impossible (e.g. a double click), 403 if wrong actor
    await x.update({ status: to }, { transaction: t });
    if (to === RS.APPROVED) await PT.findOrCreate({ where: { food_request_id: x.id }, defaults: { food_request_id: x.id }, transaction: t });
    if (to === RS.REJECTED || to === RS.CANCELLED) {
      await PT.destroy({ where: { food_request_id: x.id, volunteer_id: null }, transaction: t });
      const others = await FR.count({ where: { food_listing_id: f.id, id: { [Op.ne]: x.id }, status: ACTIVE_REQUEST }, transaction: t });
      if (!others && f.status === LS.REQUESTED) await f.update({ status: LS.AVAILABLE }, { transaction: t }); // release the food
    }
    if (to === RS.COMPLETED) {
      await f.update({ status: LS.COMPLETED }, { transaction: t });
      if (!(await Distribution.findOne({ where: { food_request_id: x.id }, transaction: t })))
        await Distribution.create({ food_request_id: x.id, food_quantity: x.requested_quantity, people_served: x.requested_servings, distributed_at: new Date() }, { transaction: t });
    }
    return { x, f, roles, donor: await Donor.findByPk(f.donor_id, { transaction: t }), ngo: await Ngo.findByPk(x.ngo_id, { transaction: t }) };
  });
  const { x, f, roles, donor, ngo } = out;
  if (to === RS.APPROVED) (await Volunteer.findAll()).forEach(v => notify(v.user_id, 'pickup', 'New pickup task', `Pick up ${f.food_name} from ${f.pickup_address}`, x.id));
  notify(roles.includes('ngo') && !roles.includes('donor') ? donor.user_id : ngo.user_id, to, 'Request ' + to.replace('_', ' '), f.food_name, x.id);
  log(q, to, 'food_request', x.id, 'Request ' + to);
  s.json(await FR.findByPk(x.id, { include: rInc() }));
}));

// ---- Volunteers / pickups (volunteer capability)
const pInc = () => [{ model: FR, as: 'FoodRequest', required: true, include: [listingInc(), ngoInc()] }];
r.get('/volunteers', auth, role('admin'), h(async (q, s) => s.json(await Volunteer.findAll({ include: [userInc()] }))));
r.get('/pickups', auth, h(async (q, s) => {
  let where = {};
  if (q.user.role !== 'admin') { const v = await getProfile('volunteer', q.user.id); const vid = v ? v.id : -1; where = q.query.mine ? { volunteer_id: vid } : { [Op.or]: [{ volunteer_id: null }, { volunteer_id: vid }] }; }
  const rows = await PT.findAll({ where, include: pInc(), order: [['id', 'DESC']] });
  // an unclaimed task is only offered while its request is still APPROVED (never for cancelled/finished ones)
  s.json(rows.filter(t => t.volunteer_id || t.FoodRequest.status === RS.APPROVED));
}));
r.post('/pickups/:id/accept', auth, h(async (q, s) => {
  const vol = await ensureProfile('volunteer', q.user); verified(vol);
  const { t, x, f, ngo, donor } = await sequelize.transaction(async tr => {
    const t = await PT.findByPk(q.params.id, lock(tr)); if (!t) throw E(404, 'Pickup task not found');
    if (t.volunteer_id) throw E(409, 'Task already accepted by another volunteer');
    const x = await FR.findByPk(t.food_request_id, lock(tr)), f = await FL.findByPk(x.food_listing_id, { transaction: tr });
    assertTransition(x.status, RS.ACCEPTED, ['volunteer']);
    await t.update({ volunteer_id: vol.id, pickup_status: 'accepted' }, { transaction: tr });
    await x.update({ status: RS.ACCEPTED }, { transaction: tr });
    return { t, x, f, ngo: await Ngo.findByPk(x.ngo_id, { transaction: tr }), donor: await Donor.findByPk(f.donor_id, { transaction: tr }) };
  });
  [ngo.user_id, donor.user_id].forEach(id => notify(id, 'accepted', 'Pickup assigned', `${q.user.name} will collect ${f.food_name}`, x.id));
  log(q, 'accepted', 'pickup_task', t.id, 'Task accepted');
  s.json(await PT.findByPk(t.id, { include: pInc() }));
}));
// Volunteer: accepted -> picked_up -> delivered (only the volunteer who holds the task).
r.put('/pickups/:id/status', auth, h(async (q, s) => {
  const to = String(q.body.status || '').trim().toLowerCase();
  if (![RS.PICKED_UP, RS.DELIVERED].includes(to)) throw E(400, 'Status must be picked_up or delivered');
  const vol = await getProfile('volunteer', q.user.id);
  const { t, x, f, ngo, donor } = await sequelize.transaction(async tr => {
    const t = await PT.findByPk(q.params.id, lock(tr)); if (!t) throw E(404, 'Pickup task not found');
    if (!vol || t.volunteer_id !== vol.id) throw E(403, 'This pickup is not assigned to you');
    const x = await FR.findByPk(t.food_request_id, lock(tr)), f = await FL.findByPk(x.food_listing_id, { transaction: tr });
    assertTransition(x.status, to, ['volunteer']);
    if (to === RS.PICKED_UP) await t.update({ pickup_status: 'picked_up', pickup_time: new Date() }, { transaction: tr });
    else await t.update({ delivery_status: 'delivered', completed_at: new Date() }, { transaction: tr });
    await x.update({ status: to }, { transaction: tr });
    return { t, x, f, ngo: await Ngo.findByPk(x.ngo_id, { transaction: tr }), donor: await Donor.findByPk(f.donor_id, { transaction: tr }) };
  });
  [ngo.user_id, donor.user_id].forEach(id => notify(id, to, to === RS.DELIVERED ? 'Delivery completed' : 'Pickup completed', f.food_name, x.id));
  log(q, to, 'pickup_task', t.id, 'Task ' + to);
  s.json(await PT.findByPk(t.id, { include: pInc() }));
}));

// ---- Notifications, feedback
r.get('/notifications', auth, h(async (q, s) => s.json(await Notification.findAll({ where: { user_id: q.user.id }, order: [['created_at', 'DESC']], limit: 15 }))));
r.put('/notifications/read', auth, h(async (q, s) => { await Notification.update({ read: true }, { where: { user_id: q.user.id } }); s.json({ ok: true }); }));
r.post('/feedback', auth, h(async (q, s) => { need(q.body, 'donationId', 'rating'); s.status(201).json(await Feedback.create({ user_id: q.user.id, donation_id: +q.body.donationId, rating: Math.min(5, Math.max(1, +q.body.rating)), comment: String(q.body.comment || '') })); }));

// ---- Stats
const stats = async () => ({ donors: await Donor.count(), ngos: await Ngo.count(), volunteers: await Volunteer.count(), available: await FL.count({ where: { status: 'available' } }), distributed: await Distribution.count(), peopleServed: (await Distribution.sum('people_served')) || 0, foodQty: Math.round((await Distribution.sum('food_quantity')) || 0) });
r.get('/stats/public', h(async (q, s) => s.json(await stats())));

// Per-capability dashboards - any logged-in user can read any of these; the numbers are simply
// zero until that user has used the capability (no forced profile creation on a GET).
// Every counter is computed from the real rows on each call - nothing is cached or hard-coded.
const servedFor = async ids => ids.length ? (await Distribution.sum('people_served', { where: { food_request_id: ids } })) || 0 : 0;
r.get('/dashboard/donor', auth, h(async (q, s) => {
  const p = await getProfile('donor', q.user.id);
  if (!p) return s.json({ total: 0, active: 0, pending: 0, completed: 0, peopleServed: 0 });
  const ids = (await FL.findAll({ where: { donor_id: p.id }, attributes: ['id'] })).map(x => x.id), inIds = ids.length ? ids : [-1];
  const done = await FR.findAll({ where: { food_listing_id: inIds, status: RS.COMPLETED }, attributes: ['id'] });
  s.json({
    total: await FL.count({ where: { donor_id: p.id, status: { [Op.ne]: LS.REMOVED } } }),
    active: await FL.count({ where: { donor_id: p.id, status: [LS.AVAILABLE, LS.REQUESTED] } }),
    pending: await FR.count({ where: { food_listing_id: inIds, status: RS.PENDING } }),
    completed: done.length, peopleServed: await servedFor(done.map(x => x.id)),
  });
}));
r.get('/dashboard/ngo', auth, h(async (q, s) => {
  const p = await getProfile('ngo', q.user.id);
  const available = await FL.count({ where: { status: LS.AVAILABLE, consume_before: { [Op.gt]: new Date() } } });
  if (!p) return s.json({ available, sent: 0, approved: 0, received: 0, peopleServed: 0 });
  const m = await FR.findAll({ where: { ngo_id: p.id }, attributes: ['id', 'status'] }), done = m.filter(x => x.status === RS.COMPLETED);
  // "approved" = requests the donor has approved (including ones that have since moved on to pickup/delivery/completed)
  s.json({ available, sent: m.length, approved: m.filter(x => ![RS.PENDING, RS.REJECTED, RS.CANCELLED].includes(x.status)).length, received: done.length, peopleServed: await servedFor(done.map(x => x.id)) });
}));
r.get('/dashboard/volunteer', auth, h(async (q, s) => {
  const p = await getProfile('volunteer', q.user.id);
  const available = await PT.count({ where: { volunteer_id: null }, include: [{ model: FR, as: 'FoodRequest', where: { status: RS.APPROVED }, required: true }] });
  if (!p) return s.json({ available, accepted: 0, completed: 0, peopleHelped: 0 });
  const t = await PT.findAll({ where: { volunteer_id: p.id }, include: [{ model: FR, as: 'FoodRequest', required: true }] });
  const done = t.filter(x => [RS.DELIVERED, RS.COMPLETED].includes(x.FoodRequest.status));
  s.json({ available, accepted: t.filter(x => [RS.ACCEPTED, RS.PICKED_UP].includes(x.FoodRequest.status)).length, completed: done.length, peopleHelped: done.reduce((a, x) => a + (x.FoodRequest.requested_servings || 0), 0) });
}));
r.get('/admin/dashboard', auth, role('admin'), h(async (q, s) => s.json({ ...(await stats()), users: await User.count(), pendingRequests: await FR.count({ where: { status: 'pending' } }), completed: await FR.count({ where: { status: 'completed' } }) })));
const grp = (m, x) => m.findAll({ attributes: [[x, 'k'], [fn('COUNT', col('id')), 'n']], group: 'k', raw: true });
r.get('/admin/statistics', auth, role('admin'), h(async (q, s) => s.json({ byCapability: [{ k: 'Donor', n: await Donor.count() }, { k: 'NGO', n: await Ngo.count() }, { k: 'Volunteer', n: await Volunteer.count() }], byCategory: await grp(FL, col('category')), monthly: (await grp(FL, fn('DATE_FORMAT', col('created_at'), '%Y-%m'))).sort((a, b) => a.k > b.k ? 1 : -1) })));
r.get('/admin/users', auth, role('admin'), h(async (q, s) => s.json(await User.findAll({ attributes: { exclude: ['password'] }, include: [{ model: Donor, as: 'Donor' }, { model: Ngo, as: 'Ngo' }, { model: Volunteer, as: 'Volunteer' }], order: [['id', 'DESC']] }))));
r.put('/admin/users/:id/status', auth, role('admin'), h(async (q, s) => {
  const u = await User.findByPk(q.params.id); if (!u) throw E(404, 'User not found'); const { status, profileType, verification_status: v } = q.body;
  if (status) { if (!['active', 'blocked'].includes(status)) throw E(400, 'Invalid status'); await u.update({ status }); }
  if (v) {
    if (!['verified', 'rejected', 'pending'].includes(v)) throw E(400, 'Invalid verification status');
    if (!PMAP[profileType]) throw E(400, 'profileType must be donor, ngo or volunteer');
    const p = await getProfile(profileType, u.id); if (!p) throw E(404, 'That user has no ' + profileType + ' profile yet');
    await p.update({ verification_status: v }); notify(u.id, 'verification', profileType[0].toUpperCase() + profileType.slice(1) + ' profile ' + v, 'Your ' + profileType + ' profile verification status: ' + v);
  }
  log(q, 'admin_update', 'user', u.id, JSON.stringify(q.body)); s.json({ message: 'Updated' });
}));
module.exports = r;
