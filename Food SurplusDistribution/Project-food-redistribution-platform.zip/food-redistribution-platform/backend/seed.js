require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const bcrypt = require('bcryptjs');
const { connect, sequelize } = require('./config/db');
const { User, Donor, Ngo, Volunteer, FoodListing, FoodRequest, PickupTask, Distribution, Notification } = require('./models');
const L = [['Kukatpally', 17.4948, 78.3996], ['Miyapur', 17.4969, 78.3548], ['Gachibowli', 17.4401, 78.3489], ['Madhapur', 17.4478, 78.3915], ['Secunderabad', 17.4399, 78.4983]];
const foods = [['Veg Biryani', 'Cooked Meals', 'veg'], ['Chicken Curry & Rice', 'Cooked Meals', 'non-veg'], ['Bread Loaves', 'Bakery', 'veg'], ['Idli & Sambar', 'Cooked Meals', 'veg'], ['Mixed Vegetables', 'Fruits & Vegetables', 'veg'], ['Wedding Buffet Leftovers', 'Cooked Meals', 'veg'], ['Packaged Biscuits', 'Packaged Food', 'veg'], ['Paneer Curry & Roti', 'Cooked Meals', 'veg'], ['Milk Packets', 'Dairy', 'veg'], ['Fruit Boxes', 'Fruits & Vegetables', 'veg'], ['Fried Rice', 'Cooked Meals', 'veg'], ['Sandwiches', 'Snacks', 'veg'], ['Egg Curry & Rice', 'Cooked Meals', 'non-veg'], ['Buns & Pastries', 'Bakery', 'veg'], ['Dal Khichdi', 'Cooked Meals', 'veg']];
// Every seeded "member" is ONE account that can act as Donor, NGO and Volunteer, to demonstrate
// the unified registration/login model - no separate donor/ngo/volunteer accounts anymore.
(async () => {
  await connect(); await sequelize.sync({ force: true });
  const pw = await bcrypt.hash('password123', 10), ph = () => '98480' + Math.floor(10000 + Math.random() * 89999);
  await User.create({ name: 'Platform Admin', email: 'admin@food.com', role: 'admin', password: pw, phone: ph(), city: 'Hyderabad', state: 'Telangana' });
  const dn = ['Spice Garden Restaurant', 'Hotel Deccan Grand', 'Campus Cafeteria', 'Fresh Mart Supermarket', 'Royal Event Caterers'], nn = ['Annapurna Trust', 'Hope Foundation', 'Seva Samithi', 'Asha Kiran NGO', 'Feed Hyderabad'];
  const D = [], N = [], V = [], now = Date.now(), H = 3600e3;
  for (let i = 0; i < 5; i++) {
    const [a, lat, lng] = L[i], addr = a + ', Hyderabad';
    const u = await User.create({ name: 'Member ' + (i + 1), email: `member${i + 1}@food.com`, role: 'user', password: pw, phone: ph(), address: addr, city: 'Hyderabad', state: 'Telangana' });
    D.push(await Donor.create({ user_id: u.id, organization_name: dn[i], address: addr, city: 'Hyderabad', state: 'Telangana', latitude: lat, longitude: lng, verification_status: 'verified' }));
    N.push(await Ngo.create({ user_id: u.id, organization_name: nn[i], registration_number: 'TS/NGO/20' + (10 + i), address: L[(i + 1) % 5][0] + ', Hyderabad', city: 'Hyderabad', state: 'Telangana', service_area: L[(i + 1) % 5][0], verification_status: 'verified' }));
    V.push(await Volunteer.create({ user_id: u.id, availability: 'Evenings & weekends', address: addr, latitude: lat, longitude: lng, verification_status: 'verified' }));
  }
  const ST = ['completed', 'completed', 'completed', 'delivered', 'picked_up', 'accepted', 'approved', 'pending', 'pending', 'rejected'];
  for (let i = 0; i < 15; i++) {
    const [name, category, food_type] = foods[i], d = D[i % 5], [a, lat, lng] = L[i % 5], st = i < 10 ? ST[i] : null, done = st === 'completed';
    const f = await FoodListing.create({ donor_id: d.id, food_name: name, category, food_type, description: 'Freshly prepared, hygienically packed surplus.', quantity: 10 + i * 3, unit: category === 'Cooked Meals' ? 'kg' : 'packs', servings: 20 + i * 5, prepared_at: new Date(now - 2 * H), consume_before: new Date(now + (done ? -1 : 6 + i) * H), pickup_address: `${a}, Hyderabad`, latitude: lat, longitude: lng, pickup_start: new Date(now), pickup_end: new Date(now + 4 * H), status: !st || st === 'rejected' ? 'available' : done ? 'completed' : 'requested' });
    if (!st) continue;
    const x = await FoodRequest.create({ food_listing_id: f.id, ngo_id: N[(i + 1) % 5].id, requested_quantity: f.quantity, requested_servings: f.servings, message: 'We can serve this today.', status: st });
    if (st !== 'pending' && st !== 'rejected') await PickupTask.create({ food_request_id: x.id, volunteer_id: st === 'approved' ? null : V[i % 5].id, pickup_status: st === 'approved' ? 'open' : st === 'accepted' ? 'accepted' : 'picked_up', delivery_status: ['delivered', 'completed'].includes(st) ? 'delivered' : 'pending', completed_at: ['delivered', 'completed'].includes(st) ? new Date() : null });
    if (done) await Distribution.create({ food_request_id: x.id, food_quantity: x.requested_quantity, people_served: x.requested_servings, distributed_at: new Date() });
    await Notification.create({ user_id: d.user_id, type: 'request', title: 'Food request ' + st, message: `${nn[(i + 1) % 5]} — ${name}`, related_id: x.id });
  }
  console.log('Seeded. Logins (password: password123): admin@food.com, member1@food.com .. member5@food.com');
  console.log('Every member account can act as Donor, NGO and Volunteer from one login.');
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
