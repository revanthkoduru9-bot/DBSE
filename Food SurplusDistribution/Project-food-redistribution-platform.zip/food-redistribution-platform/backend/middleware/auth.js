const jwt = require('jsonwebtoken');
const M = require('../models');
// One account can carry a Donor, an Ngo and a Volunteer profile at the same time, so auth no
// longer attaches a single q.profile - routes look up (or lazily create) whichever profile
// type the action needs via the profileOf() helper in routes/api.js.
// Errors are always JSON: { "error": "..." }  (401 = not logged in, 403 = not allowed).
exports.auth = async (q, s, n) => {
  let u;
  try {
    const t = (q.headers.authorization || '').replace('Bearer ', '');
    u = await M.User.findByPk(jwt.verify(t, process.env.JWT_SECRET).id);
  } catch { return s.status(401).json({ error: 'Please log in to continue' }); }
  if (!u) return s.status(401).json({ error: 'Please log in to continue' });
  if (u.status !== 'active') return s.status(403).json({ error: 'Your account has been blocked' });
  q.user = u;
  n();
};
exports.role = (...r) => (q, s, n) => r.includes(q.user.role) ? n() : s.status(403).json({ error: 'You do not have permission for this action' });
