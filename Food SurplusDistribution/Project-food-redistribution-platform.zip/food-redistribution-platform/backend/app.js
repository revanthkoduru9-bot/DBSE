const express = require('express'), cors = require('cors'), helmet = require('helmet'), path = require('path'), fs = require('fs');
const app = express();
fs.mkdirSync(path.join(__dirname, 'uploads'), { recursive: true });
app.use(helmet({ crossOriginResourcePolicy: false }), cors({ origin: process.env.CLIENT_URL }), express.json({ limit: '1mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api', require('./routes/api'));
app.use('/api', (q, s) => s.status(404).json({ error: 'Endpoint not found' }));
// Consistent JSON errors: { "error": "..." }. Only ordinary validation problems are echoed back to
// the client; any other database/Sequelize failure is logged on the server and returned as a
// generic 500 so SQL text, table names or credentials are never exposed.
app.use((e, q, s, n) => {
  const validation = ['SequelizeValidationError', 'SequelizeUniqueConstraintError'].includes(e.name) || e.name === 'MulterError';
  const st = e.status || (validation ? 400 : 500);
  if (st === 500) console.error(e);
  s.status(st).json({ error: st === 500 ? 'Something went wrong on the server' : e.message });
});
module.exports = app;
