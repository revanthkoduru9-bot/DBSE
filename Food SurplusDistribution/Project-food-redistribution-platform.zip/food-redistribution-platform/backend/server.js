require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const { connect } = require('./config/db');
const app = require('./app');
connect().then(() => app.listen(process.env.PORT || 5000, () => console.log('API running on port ' + (process.env.PORT || 5000))))
  .catch(e => { console.error('Database connection failed:', e.message); process.exit(1); });
