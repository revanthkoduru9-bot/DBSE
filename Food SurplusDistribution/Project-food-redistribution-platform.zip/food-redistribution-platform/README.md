# FoodBridge – Food Surplus Redistribution & Community Hunger Reduction Platform
React + Vite frontend · Node/Express REST API · **MySQL 8 + Sequelize** (no MongoDB).

## One account, every activity
There is **one registration and one login**. After logging in, a user lands on a hub with three
cards — **Donate Food**, **NGO / Request Food**, **Volunteer** — and can use any combination of
them from the same account, switching freely without logging out or registering again. A Donor,
NGO and Volunteer "profile" (organisation name, service area, availability, etc.) is created
automatically the first time that activity is used, or earlier via the "Edit profile" button on
each section; none of it requires a separate account.

## Technology stack
- Frontend: React, React Router, Axios, Vite
- Backend: Node.js, Express.js, JWT auth, bcrypt password hashing
- Database: MySQL 8.0 + Sequelize ORM

## Database architecture
`users` is the single table used for authentication (name, email, password, phone, address, city,
state, role = `admin`/`user`, status). `donors`, `ngos` and `volunteers` are optional profile
tables, each keyed by a **unique** `user_id` — so one user row can have a matching row in any or
all three of those tables at once, instead of three separate login systems. Everything else
(`food_listings`, `food_requests`, `pickup_tasks`, `distributions`, `notifications`,
`activity_logs`, `feedback`, `messages`) is unchanged. See `backend/models/index.js` for the full
Sequelize definitions and associations, and `database/mysql-schema.sql` for the equivalent raw SQL.

## Setup (fresh install)
1. Install Node 18+ and MySQL 8.
2. Copy `.env.example` to `.env` and set your MySQL credentials (`MYSQL_HOST`, `MYSQL_USER`,
   `MYSQL_PASSWORD`, `MYSQL_DATABASE=food_redistribution`) and a `JWT_SECRET`. Never hard-code
   these anywhere else.
3. From the project root:
```bash
npm install        # installs root, backend and frontend
npm run seed         # creates the database + tables + demo data
npm run dev           # API on :5000, web app on http://localhost:3000
```
Demo logins (password `password123`): `admin@food.com`, and `member1@food.com` … `member5@food.com`
— each member account can act as Donor, NGO **and** Volunteer at once; log in as one and open all
three dashboard cards to see it.

## Migrating an existing database (schema change from this update)
This update replaces the old `role` values (`admin/donor/ngo/volunteer`) with just `admin/user`,
and adds `address`, `city`, `state` to `users`. **This now happens automatically and safely** on
every backend startup (`backend/config/db.js` → `migrateUsersTable()`), *without* using
Sequelize's `sync({ alter: true })` — that option is unreliable for MySQL ENUM columns and will
crash with `Data truncated for column 'role'` if any row still holds a legacy value. Instead the
backend runs one explicit, idempotent migration before syncing:
1. Adds `address`/`city`/`state` to `users` if missing.
2. If `users.role` isn't already exactly `ENUM('admin','user')`, it **widens** the enum first
   (so old values remain valid), **updates** any row whose role is `donor`/`ngo`/`volunteer` (or
   anything else) to `user`, then **narrows** the enum to `ENUM('admin','user') NOT NULL DEFAULT
   'user'`. The row itself, and any Donor/NGO/Volunteer *profile* rows it already has, are left
   untouched — only the `users.role` label changes.
3. Only then does `sequelize.sync()` run (with no `alter`), which just creates whichever tables
   don't exist yet and never rewrites an existing table's columns.

So simply restarting the backend (`npm run dev`) against your existing database fixes it — no
manual step required, and no data is deleted. If you'd rather apply the same fix by hand, run:
```sql
ALTER TABLE users ADD COLUMN address VARCHAR(255) NULL;
ALTER TABLE users ADD COLUMN city VARCHAR(100) NULL;
ALTER TABLE users ADD COLUMN state VARCHAR(100) NULL;
-- widen first so 'user' becomes a legal value for every existing row
ALTER TABLE users MODIFY COLUMN role ENUM('admin','donor','ngo','volunteer','user') NOT NULL DEFAULT 'user';
UPDATE users SET role = 'user' WHERE role NOT IN ('admin','user');
-- now narrow to the final two values
ALTER TABLE users MODIFY COLUMN role ENUM('admin','user') NOT NULL DEFAULT 'user';
```
If you'd rather start clean instead, run `npm run seed` (drops and recreates everything with
demo data).

## Status vocabulary (one lowercase representation everywhere)
- **Food listing** (`food_listings.status`): `available`, `requested`, `completed`, `removed`
- **Food request** (`food_requests.status`): `pending`, `approved`, `rejected`, `cancelled`, `accepted`, `picked_up`, `delivered`, `completed`

The two lifecycles are independent. All allowed request transitions and who may perform them live in ONE place,
`backend/utils/status.js`:

| From | To | Who |
|---|---|---|
| pending | approved / rejected | donor (owner of the listing), admin |
| pending | cancelled | NGO (owner of the request), admin |
| approved | accepted | volunteer (via `POST /pickups/:id/accept`) |
| approved | cancelled | NGO, admin |
| accepted | picked_up | the volunteer holding the task |
| picked_up | delivered | the volunteer holding the task |
| delivered | completed | NGO (owner of the request) - "Confirm receipt" |

Errors are always JSON `{ "error": "..." }`: 400 invalid input, 401 not logged in, 403 not allowed, 404 not found,
409 impossible state change (e.g. a duplicate click), 500 unexpected. Older databases that still contain the
legacy status `pickup_assigned` are migrated to `accepted` automatically on backend start (no data is deleted).

## Workflow to test
Register once → log in → from the hub: open **Donate Food** and list surplus food → open
**NGO / Request Food** (same account) and request it → switch back to **Donate Food** to approve
the request → open **Volunteer** (same account, or a different member account) to accept the
pickup task → mark Picked Up → Delivered → back in **NGO**, confirm receipt (Completed, with a
distribution record). Admin: log in as `admin@food.com` to verify profiles, block/unblock users,
and remove listings.

## Architecture
```
frontend/ (Hub, DonorDashboard, NgoDashboard, VolunteerDashboard, Admin dashboard)
        │  Axios → "/api" (Vite dev proxy)
        ▼
backend/routes/api.js   — profileOf()/ensureProfile() look up or lazily create the
        │                  Donor/Ngo/Volunteer row for the logged-in user on demand
        ▼
backend/models/index.js  (Sequelize models + associations)
        │
        ▼
      MySQL (food_redistribution)
```

## API (selected)
Auth: `POST /api/auth/register|login|logout`, `GET /api/auth/me` (returns the user plus which
capabilities — donor/ngo/volunteer — they've already used)
Profiles: `GET/PUT /api/profile/:type` where `:type` is `donor`, `ngo` or `volunteer`
Food: `GET/POST /api/food`, `GET/PUT/DELETE /api/food/:id`, `GET /api/food/mine`
Requests: `POST/GET /api/requests` (`?view=donor` or `?view=ngo`), `PUT /api/requests/:id/status`
Pickups: `GET /api/pickups`, `POST /api/pickups/:id/accept`, `PUT /api/pickups/:id/status` (body `{ status: 'picked_up' | 'delivered' }`)
Per-capability dashboards: `GET /api/dashboard/donor|ngo|volunteer`
Admin: `GET /api/admin/dashboard|users|statistics`, `PUT /api/admin/users/:id/status`
(body: `{ status }` and/or `{ profileType, verification_status }`)

## Security
JWT + bcrypt password hashing, role-based middleware for admin-only routes, ownership checks on
every mutating route (a request/listing/task can only be changed by the account that owns the
matching Donor/NGO/Volunteer profile, resolved by record ownership rather than a fixed role),
input validation, Helmet, CORS via `CLIENT_URL`, parameterised Sequelize queries, secrets only in
`.env`, passwords never returned in API responses.

## Future enhancements
Leaflet map view, a UI for the `messages` table, email/SMS alerts, a charting library, complaint
management, Docker Compose for one-command MySQL setup.
